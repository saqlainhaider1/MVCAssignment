MVCPatternDemo.java
public class MVCPatternDemo {
   public static void main(String[] args) {

      Employee model  = retriveEmployeeFromDatabase();

      EmployeeView view = new EmployeeView();

      EmployeeController controller = new EmployeeController(model, view);

      controller.updateView();

      controller.setEmployeeName("Mr.Saqlain haider niazi");

      controller.updateView();
   }

   private static Employee retriveEmployeeFromDatabase(){
      Employee employee = new Employee();
      Employee.setName("noman");
      employee.setEmpId("1234");
      return employee;
   }
}

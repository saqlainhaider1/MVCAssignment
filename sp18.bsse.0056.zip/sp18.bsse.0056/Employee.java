Employee.java
public class Employee {
   private String EmpId;
   private String FirstName;
   private String LastName;
   private String Gender;
   private int HiredDated;
   private int Salary;



   public String getEmpId() {
      return EmpId;
   }
   
   public void setEmpId(String EmpId) {
      this.EmpId = EmpId;
   }
   
   public String getFirstName() {
      return LastName;
   }
   
   public void setFirstName(String FirstName) {
      this.FristName = FirstName;
   }
    public String getLastName() {
      return LastName;
   }
   public void setLastName(String LastName) {
      this.LastName = LastName;
   }
    public String getGender() {
      return LastGender;
}
public void setGender(String Gender) {
      this.Gender = Gender;
   }
   public int HiredDated() {
      return HiredDated;
}
public void setHiredDated(int HiredDated) {
      this. = HiredDated;

}

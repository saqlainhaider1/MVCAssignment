EmployeeView.java
public class EmployeeView {
   public void printEmployeeDetails(String FirstName, String LastName, String EmpId, String Gender){
      System.out.println("EmployeeView: ");
      System.out.println("FirstName: " + FirstName);
      System.out.println("LastName: " + LastName);
      System.out.println("EmpId: " + EmpId);
	  System.out.println("Gender: " + Gender);   
   }
}
